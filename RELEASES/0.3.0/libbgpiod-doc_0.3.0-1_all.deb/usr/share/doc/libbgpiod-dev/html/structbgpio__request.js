var structbgpio__request =
[
    [ "chardev_path", "structbgpio__request.html#a0c7033c1812bc46fff36afd9806c55a6", null ],
    [ "device_fd", "structbgpio__request.html#a77c290fe8bc16592203cb66c0d57f835", null ],
    [ "event", "structbgpio__request.html#a96196231357f3626deb17545c45e2842", null ],
    [ "line_values", "structbgpio__request.html#abd12f507ced3ac7368b9c70b04d42164", null ],
    [ "req", "structbgpio__request.html#a37057df823069df5f7cd061ad34d5dda", null ]
];