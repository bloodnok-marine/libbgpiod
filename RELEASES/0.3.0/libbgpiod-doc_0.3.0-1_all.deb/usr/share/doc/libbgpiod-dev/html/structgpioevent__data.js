var structgpioevent__data =
[
    [ "id", "structgpioevent__data.html#a0d248fe150efad50c7064e1cf2387b7e", null ],
    [ "timestamp", "structgpioevent__data.html#a5b0fa90a44b96bf112c2a93d44e6a846", null ]
];