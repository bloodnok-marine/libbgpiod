var bgpiodetect_8c =
[
    [ "SUMMARY", "bgpiodetect_8c.html#aabb34c8934b3515b1b632f8ddacdbc27", null ],
    [ "THIS_EXECUTABLE", "bgpiodetect_8c.html#ac3c04ffbd903c60dd478751920e49792", null ],
    [ "main", "bgpiodetect_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "print_chip_details", "bgpiodetect_8c.html#a9ffc6e5689c837d518ad706e4d577d7f", null ],
    [ "usage", "bgpiodetect_8c.html#a176e952be2dbd3dd70c504745246492a", null ]
];