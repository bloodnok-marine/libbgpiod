var searchData=
[
  ['chardev_5fpath_245',['chardev_path',['../structbgpio__request.html#a0c7033c1812bc46fff36afd9806c55a6',1,'bgpio_request']]]
];
