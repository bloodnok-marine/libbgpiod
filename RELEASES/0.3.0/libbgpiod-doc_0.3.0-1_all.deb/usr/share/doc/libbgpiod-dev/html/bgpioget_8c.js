var bgpioget_8c =
[
    [ "SUMMARY", "bgpioget_8c.html#aabb34c8934b3515b1b632f8ddacdbc27", null ],
    [ "THIS_EXECUTABLE", "bgpioget_8c.html#ac3c04ffbd903c60dd478751920e49792", null ],
    [ "get_bias", "bgpioget_8c.html#a955931932b0ecb8b08b3d2c7c03a4bc0", null ],
    [ "get_gpio_request", "bgpioget_8c.html#abd54a785101fbe89f85d42215b4c08bb", null ],
    [ "get_period", "bgpioget_8c.html#a3c198be0f22551950257eebe7d955495", null ],
    [ "get_repeat", "bgpioget_8c.html#a5d5d87b37ad992c62a49b43f1fb8dac5", null ],
    [ "main", "bgpioget_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "perform_fetches", "bgpioget_8c.html#a3081e4795db97c21393854617382a29b", null ],
    [ "usage", "bgpioget_8c.html#a176e952be2dbd3dd70c504745246492a", null ]
];