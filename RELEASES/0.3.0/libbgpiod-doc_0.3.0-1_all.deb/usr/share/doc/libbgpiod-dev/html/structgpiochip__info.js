var structgpiochip__info =
[
    [ "label", "structgpiochip__info.html#a4fd89632b9f9899d767e899e1189b965", null ],
    [ "lines", "structgpiochip__info.html#a648c32ce24f05c81fb4cc8e9646860f5", null ],
    [ "name", "structgpiochip__info.html#a49551534aaa159db3183fd1e73b6d5cd", null ]
];