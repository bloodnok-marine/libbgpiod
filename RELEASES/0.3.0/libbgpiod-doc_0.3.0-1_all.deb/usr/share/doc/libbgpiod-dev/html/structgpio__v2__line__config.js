var structgpio__v2__line__config =
[
    [ "attrs", "structgpio__v2__line__config.html#a7d7574a4593c9fbad5b375bd19a6af5b", null ],
    [ "flags", "structgpio__v2__line__config.html#adafc4d6f46ec9b170ebf4b4023e4fe11", null ],
    [ "num_attrs", "structgpio__v2__line__config.html#ad290a1c709d070d83721b98148c3cf62", null ],
    [ "padding", "structgpio__v2__line__config.html#a507412864bea66ae1ab25cfc9dd66e88", null ]
];