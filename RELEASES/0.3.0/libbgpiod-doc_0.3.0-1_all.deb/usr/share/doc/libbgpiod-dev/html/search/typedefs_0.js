var searchData=
[
  ['bgpio_5fchip_5ft_256',['bgpio_chip_t',['../bgpiod_8h.html#a169b1ab99719d57f8c4abb753b81d760',1,'bgpiod.h']]],
  ['bgpio_5frequest_5ft_257',['bgpio_request_t',['../bgpiod_8h.html#a0d63e2c63e67bc9b353b974fe53482ab',1,'bgpiod.h']]]
];
