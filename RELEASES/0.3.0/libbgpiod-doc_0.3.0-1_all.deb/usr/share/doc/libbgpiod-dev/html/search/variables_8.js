var searchData=
[
  ['size_254',['size',['../structsvector.html#a0b3a75c010c72b7bf84f0ecd809d9a71',1,'svector']]],
  ['str_255',['str',['../structsvector.html#a0e0e16d2527d07463c0ea22797c9ea65',1,'svector']]]
];
