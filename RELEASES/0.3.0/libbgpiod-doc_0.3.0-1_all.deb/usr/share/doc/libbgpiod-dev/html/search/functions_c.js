var searchData=
[
  ['vector_5felements_242',['vector_elements',['../vectors_8c.html#a602a10cf53b9ee76cc65fd95d6688169',1,'vectors.c']]],
  ['version_243',['version',['../bgpiotools_8h.html#a44d7d2885d9e2676a5e88bf5a0f09398',1,'version(char *):&#160;utils.c'],['../utils_8c.html#ac15ee90550931a696de3cddbafe8be7e',1,'version(char *this_name):&#160;utils.c']]]
];
