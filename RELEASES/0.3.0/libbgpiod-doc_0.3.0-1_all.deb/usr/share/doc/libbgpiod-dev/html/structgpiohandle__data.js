var structgpiohandle__data =
[
    [ "values", "structgpiohandle__data.html#a384bc817112455f8d71ecff8be2c3457", null ]
];