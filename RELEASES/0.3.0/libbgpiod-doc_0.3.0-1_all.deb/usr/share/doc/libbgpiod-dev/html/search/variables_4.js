var searchData=
[
  ['info_250',['info',['../structbgpio__chip__t.html#a2d0662d2619afee80fef47fec696e87b',1,'bgpio_chip_t']]]
];
