var structgpio__v2__line__info =
[
    [ "attrs", "structgpio__v2__line__info.html#a512c9229cd2c8f8f403acfdd66c41c39", null ],
    [ "consumer", "structgpio__v2__line__info.html#a259c519d38a883538c91f1ccb6301d0e", null ],
    [ "flags", "structgpio__v2__line__info.html#a729bc3d1ca4164b7e916fdab23d5c8b7", null ],
    [ "name", "structgpio__v2__line__info.html#ae0f30109112d734ac3fa1e76dced2c2f", null ],
    [ "num_attrs", "structgpio__v2__line__info.html#a00a33ed986bab5450c4300f53a88eb2f", null ],
    [ "offset", "structgpio__v2__line__info.html#a4ec34c3cd2de2a15d4781d77d1fa9ff8", null ],
    [ "padding", "structgpio__v2__line__info.html#ae90c6915a799ea32c7e204ca45a82988", null ]
];