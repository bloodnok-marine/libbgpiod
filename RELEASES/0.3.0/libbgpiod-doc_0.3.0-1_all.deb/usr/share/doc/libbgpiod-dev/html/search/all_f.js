var searchData=
[
  ['usage_142',['usage',['../bgpiodetect_8c.html#a176e952be2dbd3dd70c504745246492a',1,'usage(int exitcode):&#160;bgpiodetect.c'],['../bgpioget_8c.html#a176e952be2dbd3dd70c504745246492a',1,'usage(int exitcode):&#160;bgpioget.c'],['../bgpioinfo_8c.html#a176e952be2dbd3dd70c504745246492a',1,'usage(int exitcode):&#160;bgpioinfo.c'],['../bgpiomon_8c.html#a176e952be2dbd3dd70c504745246492a',1,'usage(int exitcode):&#160;bgpiomon.c'],['../bgpioset_8c.html#a176e952be2dbd3dd70c504745246492a',1,'usage(int exitcode):&#160;bgpioset.c'],['../bgpiowatch_8c.html#a176e952be2dbd3dd70c504745246492a',1,'usage(int exitcode):&#160;bgpiowatch.c']]],
  ['using_20the_20api_20_28howto_29_143',['Using The API (HOWTO)',['../api_usage_page.html',1,'']]],
  ['utils_2ec_144',['utils.c',['../utils_8c.html',1,'']]]
];
