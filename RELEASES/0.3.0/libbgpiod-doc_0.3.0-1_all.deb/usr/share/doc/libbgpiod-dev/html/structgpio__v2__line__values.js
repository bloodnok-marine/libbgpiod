var structgpio__v2__line__values =
[
    [ "bits", "structgpio__v2__line__values.html#a701980a3124143396c3649fee476880a", null ],
    [ "mask", "structgpio__v2__line__values.html#a1346baab2ee2beec9539eaaf89e50f7b", null ]
];