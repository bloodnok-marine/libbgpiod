var structsvector =
[
    [ "elems", "structsvector.html#a80a397913d58bd664c3f5d1777341dbb", null ],
    [ "size", "structsvector.html#a0b3a75c010c72b7bf84f0ecd809d9a71", null ],
    [ "str", "structsvector.html#a0e0e16d2527d07463c0ea22797c9ea65", null ]
];