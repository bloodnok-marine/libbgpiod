var vectors_8c =
[
    [ "SIZE_INCREMENT", "vectors_8c.html#a25a0445256bbb88210194c8f1383d875", null ],
    [ "compar", "vectors_8c.html#a97bf72909ab8a837c2ecf0e30c17cded", null ],
    [ "create_svector", "vectors_8c.html#a18d0fb13706ab238496e4a23cf122e9b", null ],
    [ "endcmp", "vectors_8c.html#a5213c2d99295b1e5e2b572729f730a62", null ],
    [ "room_for_one_more", "vectors_8c.html#a485b5cc2226a1de55026347e36e22771", null ],
    [ "svector_add_elem", "vectors_8c.html#a1ea24c8ff2083e8c1262b6bf07d3deb7", null ],
    [ "svector_find", "vectors_8c.html#a4b734bc6b8afcbff84b9a171f0f151f1", null ],
    [ "svector_sort", "vectors_8c.html#a3e786f082af3cdae25bde3d5886517a0", null ],
    [ "vector_elements", "vectors_8c.html#a602a10cf53b9ee76cc65fd95d6688169", null ]
];