var structgpio__v2__line__request =
[
    [ "config", "structgpio__v2__line__request.html#a866f74de933c0454050f316872a5527a", null ],
    [ "consumer", "structgpio__v2__line__request.html#afb10386d5311e34a1a83ae9912a4b505", null ],
    [ "event_buffer_size", "structgpio__v2__line__request.html#a55a5c4f802c2e1a3f6659fc50279c600", null ],
    [ "fd", "structgpio__v2__line__request.html#ab0c07ba82031fddf85212de64981bf7b", null ],
    [ "num_lines", "structgpio__v2__line__request.html#a998badc9fcba454fe44b4d120a188bb3", null ],
    [ "offsets", "structgpio__v2__line__request.html#a0230b5579be90e6d2427b71a02fde6df", null ],
    [ "padding", "structgpio__v2__line__request.html#a92878c289136d7e8eb4ecd6d4d5d9545", null ]
];