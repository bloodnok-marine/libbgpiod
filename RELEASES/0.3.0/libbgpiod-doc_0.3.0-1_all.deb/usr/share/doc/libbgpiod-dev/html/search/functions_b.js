var searchData=
[
  ['usage_241',['usage',['../bgpiodetect_8c.html#a176e952be2dbd3dd70c504745246492a',1,'usage(int exitcode):&#160;bgpiodetect.c'],['../bgpioget_8c.html#a176e952be2dbd3dd70c504745246492a',1,'usage(int exitcode):&#160;bgpioget.c'],['../bgpioinfo_8c.html#a176e952be2dbd3dd70c504745246492a',1,'usage(int exitcode):&#160;bgpioinfo.c'],['../bgpiomon_8c.html#a176e952be2dbd3dd70c504745246492a',1,'usage(int exitcode):&#160;bgpiomon.c'],['../bgpioset_8c.html#a176e952be2dbd3dd70c504745246492a',1,'usage(int exitcode):&#160;bgpioset.c'],['../bgpiowatch_8c.html#a176e952be2dbd3dd70c504745246492a',1,'usage(int exitcode):&#160;bgpiowatch.c']]]
];
