var searchData=
[
  ['copyright_267',['COPYRIGHT',['../bgpiotools_8h.html#a6247bc79b0a606bddbf5a90fc3a03194',1,'bgpiotools.h']]]
];
