var structgpio__v2__line__event =
[
    [ "id", "structgpio__v2__line__event.html#a6c8d09bde3133646da7e96b2d5e2951e", null ],
    [ "line_seqno", "structgpio__v2__line__event.html#a5efaedd3976d013801b326a0963f06ba", null ],
    [ "offset", "structgpio__v2__line__event.html#ad8e1f9fc5a87027ed8e01f7f051d944a", null ],
    [ "padding", "structgpio__v2__line__event.html#aca413c25c8fcb08f721a71f7307335fa", null ],
    [ "seqno", "structgpio__v2__line__event.html#ab95bdb2993f3ac070d4fdd7166495316", null ],
    [ "timestamp_ns", "structgpio__v2__line__event.html#aae60ff06c485b036c37dc6ca788fef7a", null ]
];