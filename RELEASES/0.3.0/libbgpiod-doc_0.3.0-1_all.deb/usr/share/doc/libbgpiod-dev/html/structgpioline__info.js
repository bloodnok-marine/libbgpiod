var structgpioline__info =
[
    [ "consumer", "structgpioline__info.html#a479aa1ab37bf55911280124663e38dd6", null ],
    [ "flags", "structgpioline__info.html#a4f602836ec9818938cfe34571917954d", null ],
    [ "line_offset", "structgpioline__info.html#a6a9b36e4fa9a41283331d94f1ca1bc84", null ],
    [ "name", "structgpioline__info.html#ac3b40c254eefc439407316bcb382851f", null ]
];