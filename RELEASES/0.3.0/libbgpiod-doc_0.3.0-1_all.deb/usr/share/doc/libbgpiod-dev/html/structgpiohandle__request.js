var structgpiohandle__request =
[
    [ "consumer_label", "structgpiohandle__request.html#a8074823b35c3aaf95a321c9644dfebfc", null ],
    [ "default_values", "structgpiohandle__request.html#aba3bdd969fde93bfcd89758ff16b5f3f", null ],
    [ "fd", "structgpiohandle__request.html#abba17da873fcfac089e9491db7f13100", null ],
    [ "flags", "structgpiohandle__request.html#ae7ec330bc556165c90e0aa2fbac3dec8", null ],
    [ "lineoffsets", "structgpiohandle__request.html#aaa52070a354344969483df779c2b74f1", null ],
    [ "lines", "structgpiohandle__request.html#a5f0b14c9b6aa5c447c0bd727448a4180", null ]
];