var searchData=
[
  ['setting_20gpio_20line_20outputs_127',['Setting GPIO Line Outputs',['../gpio_set_api_page.html',1,'']]],
  ['size_128',['size',['../structsvector.html#a0b3a75c010c72b7bf84f0ecd809d9a71',1,'svector']]],
  ['size_5fincrement_129',['SIZE_INCREMENT',['../vectors_8c.html#a25a0445256bbb88210194c8f1383d875',1,'vectors.c']]],
  ['str_130',['str',['../structsvector.html#a0e0e16d2527d07463c0ea22797c9ea65',1,'svector']]],
  ['stractive_131',['stractive',['../bgpiotools_8h.html#a2887a667cf2200a647d8f8a4efbf95e6',1,'stractive(char *arg, uint64_t *bias):&#160;utils.c'],['../utils_8c.html#a7ce8cea28c8ca976a62c9947c6811740',1,'stractive(char *arg, uint64_t *flags):&#160;utils.c']]],
  ['strbias_132',['strbias',['../bgpiotools_8h.html#ab5662b5fc98b1dea31f192a450592e21',1,'strbias(char *arg, uint64_t *bias):&#160;utils.c'],['../utils_8c.html#aa7a075dc2f96d9b8114ab6c2cb59efa1',1,'strbias(char *arg, uint64_t *flags):&#160;utils.c']]],
  ['stredge_133',['stredge',['../bgpiotools_8h.html#a13c7e8a42a92659492ee547e85ae426e',1,'stredge(char *arg, uint64_t *flags):&#160;utils.c'],['../utils_8c.html#a13c7e8a42a92659492ee547e85ae426e',1,'stredge(char *arg, uint64_t *flags):&#160;utils.c']]],
  ['streq_134',['streq',['../bgpiotools_8h.html#a77fa234acb9d88f85290b02c89e8168f',1,'bgpiotools.h']]],
  ['stroutputdrive_135',['stroutputdrive',['../bgpiotools_8h.html#a7af9a6c62cf0ab9590811ed655e59954',1,'stroutputdrive(char *arg, uint64_t *flags):&#160;utils.c'],['../utils_8c.html#a7af9a6c62cf0ab9590811ed655e59954',1,'stroutputdrive(char *arg, uint64_t *flags):&#160;utils.c']]],
  ['summary_136',['SUMMARY',['../bgpioget_8c.html#aabb34c8934b3515b1b632f8ddacdbc27',1,'SUMMARY():&#160;bgpioget.c'],['../bgpiowatch_8c.html#aabb34c8934b3515b1b632f8ddacdbc27',1,'SUMMARY():&#160;bgpiowatch.c'],['../bgpioset_8c.html#aabb34c8934b3515b1b632f8ddacdbc27',1,'SUMMARY():&#160;bgpioset.c'],['../bgpiomon_8c.html#aabb34c8934b3515b1b632f8ddacdbc27',1,'SUMMARY():&#160;bgpiomon.c'],['../bgpioinfo_8c.html#aabb34c8934b3515b1b632f8ddacdbc27',1,'SUMMARY():&#160;bgpioinfo.c'],['../bgpiodetect_8c.html#aabb34c8934b3515b1b632f8ddacdbc27',1,'SUMMARY():&#160;bgpiodetect.c']]],
  ['svector_137',['svector',['../bgpiotools_8h.html#a21561a6bb3209f841612bb3cb2b03532',1,'svector():&#160;bgpiotools.h'],['../structsvector.html',1,'svector']]],
  ['svector_5fadd_5felem_138',['svector_add_elem',['../bgpiotools_8h.html#a4ba8f710d9d5ffbde4918eaed3d70df8',1,'svector_add_elem(svector *vec, char *elem):&#160;vectors.c'],['../vectors_8c.html#a1ea24c8ff2083e8c1262b6bf07d3deb7',1,'svector_add_elem(svector *svec, char *elem):&#160;vectors.c']]],
  ['svector_5ffind_139',['svector_find',['../bgpiotools_8h.html#a4b734bc6b8afcbff84b9a171f0f151f1',1,'svector_find(svector *vec, char *match, finder_fn_t finder):&#160;vectors.c'],['../vectors_8c.html#a4b734bc6b8afcbff84b9a171f0f151f1',1,'svector_find(svector *vec, char *match, finder_fn_t finder):&#160;vectors.c']]],
  ['svector_5fsort_140',['svector_sort',['../bgpiotools_8h.html#a756378ce4670fa43aa30a7dcb06341d0',1,'svector_sort(svector *vec):&#160;vectors.c'],['../vectors_8c.html#a3e786f082af3cdae25bde3d5886517a0',1,'svector_sort(svector *svec):&#160;vectors.c']]]
];
