var annotated_dup =
[
    [ "bgpio_chip_t", "structbgpio__chip__t.html", "structbgpio__chip__t" ],
    [ "bgpio_request", "structbgpio__request.html", "structbgpio__request" ],
    [ "gpio_v2_line_attribute", "structgpio__v2__line__attribute.html", "structgpio__v2__line__attribute" ],
    [ "gpio_v2_line_config", "structgpio__v2__line__config.html", "structgpio__v2__line__config" ],
    [ "gpio_v2_line_config_attribute", "structgpio__v2__line__config__attribute.html", "structgpio__v2__line__config__attribute" ],
    [ "gpio_v2_line_event", "structgpio__v2__line__event.html", "structgpio__v2__line__event" ],
    [ "gpio_v2_line_info", "structgpio__v2__line__info.html", "structgpio__v2__line__info" ],
    [ "gpio_v2_line_info_changed", "structgpio__v2__line__info__changed.html", "structgpio__v2__line__info__changed" ],
    [ "gpio_v2_line_request", "structgpio__v2__line__request.html", "structgpio__v2__line__request" ],
    [ "gpio_v2_line_values", "structgpio__v2__line__values.html", "structgpio__v2__line__values" ],
    [ "gpiochip_info", "structgpiochip__info.html", "structgpiochip__info" ],
    [ "gpioevent_data", "structgpioevent__data.html", "structgpioevent__data" ],
    [ "gpioevent_request", "structgpioevent__request.html", "structgpioevent__request" ],
    [ "gpiohandle_config", "structgpiohandle__config.html", "structgpiohandle__config" ],
    [ "gpiohandle_data", "structgpiohandle__data.html", "structgpiohandle__data" ],
    [ "gpiohandle_request", "structgpiohandle__request.html", "structgpiohandle__request" ],
    [ "gpioline_info", "structgpioline__info.html", "structgpioline__info" ],
    [ "gpioline_info_changed", "structgpioline__info__changed.html", "structgpioline__info__changed" ],
    [ "svector", "structsvector.html", "structsvector" ]
];