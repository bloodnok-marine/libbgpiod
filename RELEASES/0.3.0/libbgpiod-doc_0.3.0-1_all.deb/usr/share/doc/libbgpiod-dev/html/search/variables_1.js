var searchData=
[
  ['device_5ffd_246',['device_fd',['../structbgpio__request.html#a77c290fe8bc16592203cb66c0d57f835',1,'bgpio_request']]]
];
