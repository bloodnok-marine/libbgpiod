var structgpio__v2__line__attribute =
[
    [ "debounce_period_us", "structgpio__v2__line__attribute.html#a0a9f07e93ea2e64e1fa50b95a7a2acab", null ],
    [ "flags", "structgpio__v2__line__attribute.html#a8df60084976a2a2d42028bbc5b5bf67c", null ],
    [ "id", "structgpio__v2__line__attribute.html#afb010fd116a614799dff5946761fcca3", null ],
    [ "padding", "structgpio__v2__line__attribute.html#af358031b4bf84c9ea2c4ec5713c75803", null ],
    [ "values", "structgpio__v2__line__attribute.html#a221c1e34f1a13861d95caadd3e363e28", null ]
];