var structgpio__v2__line__config__attribute =
[
    [ "attr", "structgpio__v2__line__config__attribute.html#a5fd9b75015f576ff8cb94a054c176d55", null ],
    [ "mask", "structgpio__v2__line__config__attribute.html#a1635a8b6d87029c0b46daaaa3c9d420f", null ]
];