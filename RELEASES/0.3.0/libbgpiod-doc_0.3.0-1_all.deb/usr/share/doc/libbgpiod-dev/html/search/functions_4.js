var searchData=
[
  ['free_5fchip_5fpaths_208',['free_chip_paths',['../bgpiotools_8h.html#a212c6936bdd64b790c80071e722ca044',1,'free_chip_paths(svector *paths):&#160;utils.c'],['../utils_8c.html#a212c6936bdd64b790c80071e722ca044',1,'free_chip_paths(svector *paths):&#160;utils.c']]]
];
