var structgpioline__info__changed =
[
    [ "event_type", "structgpioline__info__changed.html#a0ac6f8cbe7ac9138f432a0d7ba19a82a", null ],
    [ "info", "structgpioline__info__changed.html#a13717f0944e6c07008ef48d457fb66d9", null ],
    [ "padding", "structgpioline__info__changed.html#a97a35b13ab190ac03a89c9088ae15541", null ],
    [ "timestamp", "structgpioline__info__changed.html#a662fea03a71e6c6bfc710a35f4d66f96", null ]
];