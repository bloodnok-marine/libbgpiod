var searchData=
[
  ['debounce_5fdisabled_51',['DEBOUNCE_DISABLED',['../bgpiomon_8c.html#afa16742ced6802f1a6f26bd19e649c90',1,'bgpiomon.c']]],
  ['device_5ffd_52',['device_fd',['../structbgpio__request.html#a77c290fe8bc16592203cb66c0d57f835',1,'bgpio_request']]]
];
