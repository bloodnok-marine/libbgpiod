var structgpioevent__request =
[
    [ "consumer_label", "structgpioevent__request.html#a9c78ebe2cf12f8826c3c20c300fc7604", null ],
    [ "eventflags", "structgpioevent__request.html#a342ff534bfad7595e2aaadd6a8870065", null ],
    [ "fd", "structgpioevent__request.html#ac61d3e6bac788b25a35ccbb02e1ee47b", null ],
    [ "handleflags", "structgpioevent__request.html#a518d40bec521f25de29c4abbf442c2cd", null ],
    [ "lineoffset", "structgpioevent__request.html#aa924bd1732bf30c460d3d247e47bed4c", null ]
];