var structgpiohandle__config =
[
    [ "default_values", "structgpiohandle__config.html#a48b55a524e8524032d227a5dd520fce0", null ],
    [ "flags", "structgpiohandle__config.html#a8eacbadf3eb6f1c4d849f735fc2457ef", null ],
    [ "padding", "structgpiohandle__config.html#aa6e1cc415752921cea078d91fce3b957", null ]
];