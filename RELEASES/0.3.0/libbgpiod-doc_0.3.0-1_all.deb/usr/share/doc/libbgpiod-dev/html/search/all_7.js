var searchData=
[
  ['identifying_20gpio_20chip_20devices_90',['Identifying GPIO Chip Devices',['../chip_detect_api_page.html',1,'']]],
  ['info_91',['info',['../structbgpio__chip__t.html#a2d0662d2619afee80fef47fec696e87b',1,'bgpio_chip_t']]],
  ['installing_92',['Installing',['../installing-page.html',1,'']]]
];
