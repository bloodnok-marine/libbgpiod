var searchData=
[
  ['size_5fincrement_276',['SIZE_INCREMENT',['../vectors_8c.html#a25a0445256bbb88210194c8f1383d875',1,'vectors.c']]],
  ['streq_277',['streq',['../bgpiotools_8h.html#a77fa234acb9d88f85290b02c89e8168f',1,'bgpiotools.h']]],
  ['summary_278',['SUMMARY',['../bgpiodetect_8c.html#aabb34c8934b3515b1b632f8ddacdbc27',1,'SUMMARY():&#160;bgpiodetect.c'],['../bgpioget_8c.html#aabb34c8934b3515b1b632f8ddacdbc27',1,'SUMMARY():&#160;bgpioget.c'],['../bgpioinfo_8c.html#aabb34c8934b3515b1b632f8ddacdbc27',1,'SUMMARY():&#160;bgpioinfo.c'],['../bgpiomon_8c.html#aabb34c8934b3515b1b632f8ddacdbc27',1,'SUMMARY():&#160;bgpiomon.c'],['../bgpioset_8c.html#aabb34c8934b3515b1b632f8ddacdbc27',1,'SUMMARY():&#160;bgpioset.c'],['../bgpiowatch_8c.html#aabb34c8934b3515b1b632f8ddacdbc27',1,'SUMMARY():&#160;bgpiowatch.c']]]
];
