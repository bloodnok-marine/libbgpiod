var structgpio__v2__line__info__changed =
[
    [ "event_type", "structgpio__v2__line__info__changed.html#ad559471791cdb388bb15e0ec7c2fb4ab", null ],
    [ "info", "structgpio__v2__line__info__changed.html#ac535c82dcaae243492c9e42a7e794ae8", null ],
    [ "padding", "structgpio__v2__line__info__changed.html#a1eb9ec4b2233b9fb6c1473efe8a60e64", null ],
    [ "timestamp_ns", "structgpio__v2__line__info__changed.html#a62a83c530e599863d517d22d8823bd83", null ]
];