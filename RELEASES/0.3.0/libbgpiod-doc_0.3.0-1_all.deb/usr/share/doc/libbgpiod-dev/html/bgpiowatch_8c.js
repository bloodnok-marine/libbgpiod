var bgpiowatch_8c =
[
    [ "SUMMARY", "bgpiowatch_8c.html#aabb34c8934b3515b1b632f8ddacdbc27", null ],
    [ "THIS_EXECUTABLE", "bgpiowatch_8c.html#ac3c04ffbd903c60dd478751920e49792", null ],
    [ "get_gpio_chip", "bgpiowatch_8c.html#a82b3b80284b1dc5741d296d38aae036a", null ],
    [ "get_repeat", "bgpiowatch_8c.html#a5d5d87b37ad992c62a49b43f1fb8dac5", null ],
    [ "get_timeout", "bgpiowatch_8c.html#aae10f1cca9e366f98376c3804f1d24fc", null ],
    [ "main", "bgpiowatch_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "usage", "bgpiowatch_8c.html#a176e952be2dbd3dd70c504745246492a", null ],
    [ "watch_lines", "bgpiowatch_8c.html#a82dacc717269d333470bd058de410f62", null ]
];