var dir_4eeb864c4eec08c7d6b9d3b0352cfdde =
[
    [ "bgpiodetect.c", "bgpiodetect_8c.html", "bgpiodetect_8c" ],
    [ "bgpioget.c", "bgpioget_8c.html", "bgpioget_8c" ],
    [ "bgpioinfo.c", "bgpioinfo_8c.html", "bgpioinfo_8c" ],
    [ "bgpiomon.c", "bgpiomon_8c.html", "bgpiomon_8c" ],
    [ "bgpioset.c", "bgpioset_8c.html", "bgpioset_8c" ],
    [ "bgpiotools.h", "bgpiotools_8h.html", "bgpiotools_8h" ],
    [ "bgpiowatch.c", "bgpiowatch_8c.html", "bgpiowatch_8c" ],
    [ "utils.c", "utils_8c.html", "utils_8c" ],
    [ "vectors.c", "vectors_8c.html", "vectors_8c" ]
];