var searchData=
[
  ['compar_205',['compar',['../vectors_8c.html#a97bf72909ab8a837c2ecf0e30c17cded',1,'vectors.c']]],
  ['create_5fsvector_206',['create_svector',['../bgpiotools_8h.html#a18d0fb13706ab238496e4a23cf122e9b',1,'create_svector(size_t size):&#160;vectors.c'],['../vectors_8c.html#a18d0fb13706ab238496e4a23cf122e9b',1,'create_svector(size_t size):&#160;vectors.c']]]
];
