var bgpiomon_8c =
[
    [ "DEBOUNCE_DISABLED", "bgpiomon_8c.html#afa16742ced6802f1a6f26bd19e649c90", null ],
    [ "SUMMARY", "bgpiomon_8c.html#aabb34c8934b3515b1b632f8ddacdbc27", null ],
    [ "THIS_EXECUTABLE", "bgpiomon_8c.html#ac3c04ffbd903c60dd478751920e49792", null ],
    [ "get_bias", "bgpiomon_8c.html#a955931932b0ecb8b08b3d2c7c03a4bc0", null ],
    [ "get_debounce", "bgpiomon_8c.html#a9772bb99cc0d1a2465027b69176b6e9c", null ],
    [ "get_edge", "bgpiomon_8c.html#af4943b99b65ccae261c4f1c5d092511b", null ],
    [ "get_gpio_request", "bgpiomon_8c.html#abd54a785101fbe89f85d42215b4c08bb", null ],
    [ "get_repeat", "bgpiomon_8c.html#a5d5d87b37ad992c62a49b43f1fb8dac5", null ],
    [ "get_timeout", "bgpiomon_8c.html#aae10f1cca9e366f98376c3804f1d24fc", null ],
    [ "main", "bgpiomon_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "process_edge", "bgpiomon_8c.html#ab1a16c0f58abfdfdcc8bdb945249478d", null ],
    [ "usage", "bgpiomon_8c.html#a176e952be2dbd3dd70c504745246492a", null ]
];